<?php

/**
 * @file
 * A settings.php fixture file scaffolded from the scaffold-override-fixture.
 */
