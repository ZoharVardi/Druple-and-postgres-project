<?php

namespace Drupal\Driver\Database\CoreFake\Install;

use Drupal\Core\Database\Driver\CoreFake\Install\Tasks as BaseInstallTasks;

class Tasks extends BaseInstallTasks {

}
