<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Tests\Core\Database\Stub\StubSchema;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Schema.
 */
class Schema extends StubSchema {

}
