<?php

/**
 * @file
 * Test version of index.php from drupal/core.
 */
