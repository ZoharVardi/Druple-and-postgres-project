<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\ExceptionHandler as BaseExceptionHandler;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\ExceptionHandler.
 */
class ExceptionHandler extends BaseExceptionHandler {

}
