<?php
// phpcs:ignoreFile
print 'PHP was executed!';
