<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Select as QuerySelect;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Select.
 */
class Select extends QuerySelect {

}
