<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\search\ViewsSearchQuery as CoreViewsSearchQuery;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\search\ViewsSearchQuery.
 */
class ViewsSearchQuery extends CoreViewsSearchQuery {

}
