<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Delete as QueryDelete;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Delete.
 */
class Delete extends QueryDelete {

}
